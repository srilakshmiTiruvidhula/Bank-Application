package servlet_classes;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.cj.jdbc.Driver;
@WebServlet("/signup")

public class Sign_up extends  HttpServlet{
	
@Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
	String value1=req.getParameter("email");
	String value2=req.getParameter("name");
	String value3=req.getParameter("password");

	long value4=Long.parseLong(req.getParameter("phone"));
	
	String value5=req.getParameter("gender");

	String value6=req.getParameter("address");
	int value7=Integer.parseInt(req.getParameter("balance"));

	try {
		DriverManager.registerDriver(new Driver());
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank_servlet", "root", "root");
		PreparedStatement ps1=con.prepareStatement("select * from bank_servlet.bank where email=?");
		ps1.setString(1, value1);
		ResultSet rs=ps1.executeQuery();
		if(rs.next()==false) {
		PreparedStatement ps=con.prepareStatement("INSERT INTO bank_servlet.bank VALUES (?,?,?,?,?,?,?)");
		ps.setString(1, value1);
		ps.setString(2, value2);
		ps.setString(3, value3);
		ps.setLong(4, value4);
		ps.setString(5, value5);
		ps.setString(6, value6);
		ps.setInt(7, value7);

		 ps.execute();
		
				req.setAttribute("created", "*account is created, now login");
			RequestDispatcher d=req.getRequestDispatcher("Index.jsp");
			d.forward(req, resp);
			
	}
		else {
			req.setAttribute("existingemail", "*the entered email is already exist");
			RequestDispatcher d=req.getRequestDispatcher("Signup.jsp");
			d.include(req, resp);
		}
	}catch (SQLException e) {
		// TODO Auto-generated catch block
		
		e.printStackTrace();
	}
	
}
	
}

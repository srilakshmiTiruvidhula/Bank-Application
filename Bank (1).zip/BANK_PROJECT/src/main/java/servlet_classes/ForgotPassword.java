package servlet_classes;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/password")

public class ForgotPassword extends  HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String email=req.getParameter("email");
		String newpassword=req.getParameter("newpassword");
		String confpassword=req.getParameter("confpassword");

		try {
			DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank_servlet", "root", "root");
			PreparedStatement ps=con.prepareStatement("select * from bank_servlet.bank WHERE email = ?");
			
			ps.setString(1, email);
			ResultSet rs=ps.executeQuery();
			if(rs.next()) {
				
					
					if(newpassword.equals(confpassword)) {
						PreparedStatement ps1=con.prepareStatement("UPDATE bank_servlet.bank SET password = ? WHERE email = ?");
						ps1.setString(1, confpassword);
						ps1.setString(2, email);
						ps.execute();
					req.setAttribute("updatedpassword", "*password is successfully updated,please login");
					RequestDispatcher d=req.getRequestDispatcher("Index.jsp");
					d.forward(req, resp);
//					req.setAttribute("existingpassword", "*new password should not match with old password");
//					RequestDispatcher d=req.getRequestDispatcher("ForgotPassword.jsp");
//					d.include(req, resp);
					
					}
					else {
						req.setAttribute("confpass", "*password and confrim password should match");
						RequestDispatcher d=req.getRequestDispatcher("ForgotPassword.jsp");
						d.include(req, resp);
					}
					
			}
			else {
				req.setAttribute("nouserfound", "*no user found on this email address");
				RequestDispatcher d=req.getRequestDispatcher("ForgotPassword.jsp");
				d.include(req, resp);
			}
		}
				catch (SQLException e) {
					
				
			e.printStackTrace();
		}
	}
}

package servlet_classes;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/balance")

public class Balance extends  HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String email=req.getParameter("email");
		String password=req.getParameter("password");
		try {
			DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank_servlet", "root", "root");
			PreparedStatement ps=con.prepareStatement("select * from bank_servlet.bank where email=?");
			ps.setString(1, email);
			ResultSet rs=ps.executeQuery();
			if(rs.next()) {
				if(rs.getString("password").equals(password)) {
					req.setAttribute("balance",rs.getInt("balance"));
					RequestDispatcher d=req.getRequestDispatcher("showbal.jsp");
					d.forward(req, resp);
					
			}
				else {
					req.setAttribute("pmsg", "*password is INVALID..");
					System.out.println("incorect pass");
					RequestDispatcher d=req.getRequestDispatcher("balance.jsp");
					d.include(req, resp);
				}
			}
			else {
				req.setAttribute("emsg", "*email is INVALID..");
				System.out.println("incorect email");
				RequestDispatcher d=req.getRequestDispatcher("balance.jsp");
				d.include(req, resp);
			}
			ps.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}

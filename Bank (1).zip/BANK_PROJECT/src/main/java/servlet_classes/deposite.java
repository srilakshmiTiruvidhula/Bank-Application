package servlet_classes;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/deposite")

public class deposite extends  HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String email=req.getParameter("email");
		int amount=Integer.parseInt(req.getParameter("amount"));
		String password=req.getParameter("password");
		try {
			DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank_servlet", "root", "root");
			PreparedStatement ps=con.prepareStatement("select * from bank_servlet.bank where email=?");
			ps.setString(1, email);
			ResultSet rs=ps.executeQuery();
			if(rs.next()) {
				if(rs.getString("password").equals(password)) {
					
					if(rs.getInt("balance")>0) {
						int newamount=rs.getInt("balance")+amount;
						PreparedStatement ps1=con.prepareStatement("update bank_servlet.bank SET balance = ? WHERE email =?");
						ps1.setInt(1, newamount);
						ps1.setString(2, email);
					req.setAttribute("balance",newamount);
					
					ps1.execute();
					RequestDispatcher d=req.getRequestDispatcher("showbal.jsp");
					d.forward(req, resp);}
					else {
						req.setAttribute("insuffbal","*Amount should be greater than zero");
						RequestDispatcher d=req.getRequestDispatcher("deposite.jsp");
						d.include(req, resp);
					}
					
			}
				else {
					req.setAttribute("pmsg", "*password is INVALID..");
					System.out.println("incorect pass");
					RequestDispatcher d=req.getRequestDispatcher("balance.jsp");
					d.include(req, resp);
				}
			}
			else {
				req.setAttribute("emsg", "*email is INVALID..");
				System.out.println("incorect email");
				RequestDispatcher d=req.getRequestDispatcher("balance.jsp");
				d.include(req, resp);
			}
			ps.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
package servlet_classes;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.cj.jdbc.Driver;
@WebServlet("/update")

public class Update extends  HttpServlet{
	
@Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
	String value1=req.getParameter("email");
	String value2=req.getParameter("name");
	String value3=req.getParameter("password");

	long value4=Long.parseLong(req.getParameter("phone"));
	
	String value5=req.getParameter("gender");

	String value6=req.getParameter("address");
	try {
		DriverManager.registerDriver(new Driver());
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank_servlet", "root", "root");
		PreparedStatement ps1=con.prepareStatement("select * from bank_servlet.bank where email=?");
		ps1.setString(1, value1);
		ResultSet rs=ps1.executeQuery();
		if(rs.next()) {
			
				PreparedStatement ps=con.prepareStatement("UPDATE bank_servlet.bank SET name = ?,password = ?,phone = ?,gender = ?,address = ? WHERE email = ?");
				ps.setString(1, value2);
				ps.setString(2, value3);
				
				ps.setLong(3, value4);
				ps.setString(4, value3);
				ps.setString(5, value5);
				ps.setString(6, value1);
				
					ps.execute();
				req.setAttribute("updatedprofile", "*profile is successfully updated,please login");
				RequestDispatcher d=req.getRequestDispatcher("Index.jsp");
				d.forward(req, resp);
		
		}
		else {
			req.setAttribute("emailnotexist", "*the entered email is not exist");
			RequestDispatcher d=req.getRequestDispatcher("Update.jsp");
			d.include(req, resp);
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		
		e.printStackTrace();
	}
	
}
	
}

package servlet_classes;

public class Transactions {

}

package servlet_classes;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/delete")
public class DeleteAccount extends  HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String email=req.getParameter("email");
		String password=req.getParameter("password");


		try {
			DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank_servlet", "root", "root");
			PreparedStatement ps=con.prepareStatement("select * from bank_servlet.bank WHERE email = ? and password = ?");
			
			ps.setString(1, email);
			ps.setString(2, password);
			ResultSet rs=ps.executeQuery();
			if(rs.next()) {
				
					
					if(rs.getString("password").equals(password)) {
						PreparedStatement ps1=con.prepareStatement("delete from bank_servlet.bank where email = ? and password = ?");
						ps1.setString(1, req.getParameter(email));
						ps1.setString(2, req.getParameter(password));
					ps.execute();
					req.setAttribute("accountdeleted", "*account is deleted,if u need account please signup");
					RequestDispatcher d=req.getRequestDispatcher("Index.jsp");
					d.forward(req, resp);
					}
					else {
						req.setAttribute("incorectpass", "*password is incorect");
						RequestDispatcher d=req.getRequestDispatcher("delete.jsp");
						d.include(req, resp);
					}
					}
				
			else {
				req.setAttribute("nouserfoundtodelete", "*no user found on this email address");
				RequestDispatcher d=req.getRequestDispatcher("delete.jsp");
				d.include(req, resp);
			}
		}
		catch (SQLException e) {
			
			e.printStackTrace();
		}
	}
}
